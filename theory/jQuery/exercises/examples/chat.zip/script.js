// Call setup after document loads
$(setUp);

// Last received message id
var last_id = -1;

// Initial setup
function setUp() {
  // Setup for sumbmit event
  $("form").submit(sendMessage);

  // Setup automatic refresh
  window.setInterval(refresh, 5000);
}

// Refresh messages
function refresh() {
  $.getJSON("sendmessage.php", {'last_id': last_id}, messagesReceived);
}

// Send message
function sendMessage(event) {
  var username = $("input[name=username]").val();
  var message = $("input[name=message]").val();

  // Delete sent message 
  $("input[name=message]").val("");

  $.getJSON("sendmessage.php", {'last_id': last_id, 'username': username, 'text': message}, messagesReceived);

  return false;
}

// Called when messages are received
function messagesReceived(data) {
  $.each(data, lineReceived);
}

// Called for each line received
function lineReceived(index, value) {
  // Create a new line
  var line = $('<div class="line"></div>');

  // Assemble new line
  line.append('<span class="time">' + value.time + '</span>');
  line.append('<span class="username">' + value.username + ':</span>');
  line.append('<span class="message">' + value.text + '</span>');

  // Add new line
  $("#chat").append(line);

  // Scroll to bottom of messages div
  $("#chat").scrollTop($("#chat").prop("scrollHeight"));
 
  // Update last received id  
  last_id = value.id;
}
