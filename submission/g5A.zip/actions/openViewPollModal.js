$(document).ready(function() {
	$('#viewPollModal').modal('show');
});
