CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  name VARCHAR
);

INSERT INTO products VALUES (NULL, 'Apples');
INSERT INTO products VALUES (NULL, 'Bananas');
INSERT INTO products VALUES (NULL, 'Grapefruit');
INSERT INTO products VALUES (NULL, 'Oranges');
INSERT INTO products VALUES (NULL, 'Pears');
INSERT INTO products VALUES (NULL, 'Pineapples');
